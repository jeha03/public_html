<?php

namespace App\Models\Temp;




 class InfoDashboard
 {
    public $id;
    public $username;
    public $dateauth;
    public $count_characters;
    public $name_server;
    public $server_id;
 }