<?php

namespace App\Models\Temp;




 class InfoAdminDashboard
 {
    public $id;
    public $username;
    public $email;
    public $datereg;
    public $count_accounts;
    public $count_chars;
    public $last_ip;
    public $is_blocked;
 }