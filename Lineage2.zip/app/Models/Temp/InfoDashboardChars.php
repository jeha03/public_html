<?php

namespace App\Models\Temp;




 class InfoDashboardChars
 {
    public $id;
    public $char_name;
    public $account_name;
    public $lvl;
    public $clan_name;
    public $pvp;
    public $pk;
    public $last_data;
    public $server_name;
    public $online;
 }