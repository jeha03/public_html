<?php

namespace App\Models\Temp\Promo;




 class TempInfoCode
 {
    public $id;
    public $code;
    public $account_name;
    public $char_name;
    public $created_at;

   

 }