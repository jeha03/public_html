<?php

 namespace App\Service\PersonalArea\AdminConnect;


    interface IAdminConnect
    {
       public function getDataIpAddress();
    }

?>