<?php

 namespace App\Service\Sheldure;
 
    interface ISheldure
    {
       function calcInfoServers();

       function calcStaticCharacters();

       function calcStaticClans();
    }

?>