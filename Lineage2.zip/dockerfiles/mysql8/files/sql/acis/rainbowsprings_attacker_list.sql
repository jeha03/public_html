CREATE TABLE IF NOT EXISTS `rainbowsprings_attacker_list` (
  `clanId` INT NOT NULL DEFAULT 0,
  `war_decrees_count`INT NOT NULL DEFAULT 0,
  PRIMARY KEY `clanId` (`clanId`)
);