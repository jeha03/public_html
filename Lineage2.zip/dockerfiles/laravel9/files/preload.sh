#!/bin/bash
#printenv > env.txt
#cat /var/spool/cron/crontabs/bitnami >> env.txt
#cat env.txt > /var/spool/cron/crontabs/bitnami
